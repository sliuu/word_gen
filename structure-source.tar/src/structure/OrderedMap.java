package structure;

public interface OrderedMap extends Map
{
}
